1. Add client's analysis log(-s) to "ab_client" folder.
2. Add vendor's analysis log to "ab_ling" folder.
3. Run 